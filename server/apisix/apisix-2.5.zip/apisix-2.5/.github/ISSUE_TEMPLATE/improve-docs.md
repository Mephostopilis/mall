---
name: Improve Docs
about: Improve docs for Apache APISIX
labels: doc, 'good first issue'
---

# Improve Docs

## Please describe which part of docs should be improved or typo fixed

A clear and concise description of what you want and what your use case is.

## Describe the solution you'd like

A clear and concise description of what you want to happen.
